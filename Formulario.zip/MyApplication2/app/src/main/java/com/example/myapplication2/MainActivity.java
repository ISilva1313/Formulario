package com.example.myapplication2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.Calendar;

import android.widget.Button;
import android.widget.EditText;
import android.widget.DatePicker;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    EditText nombre, telefono, email, descripcion;
    Button siguiente;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nombre = (EditText) findViewById(R.id.editNombre);
        telefono = (EditText) findViewById(R.id.editTelefono);
        email = (EditText) findViewById(R.id.editEmail);
        descripcion = (EditText) findViewById(R.id.editDescripcion);
        siguiente = (Button) findViewById(R.id.btnSiguiente);


        siguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nom = nombre.getText().toString();
                String tel = telefono.getText().toString();
                String mail = email.getText().toString();
                String desc = descripcion.getText().toString();

                Intent i = new Intent(MainActivity.this, DatosPersonales.class);

                i.putExtra("nom", nom);
                i.putExtra("tel", tel);
                i.putExtra("mail", mail);
                i.putExtra("desc", desc);
                startActivity(i);

            }
        });


    }
     @Override
     public void onBackPressed() {
                super.onBackPressed();
    }
}