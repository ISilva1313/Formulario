package com.example.myapplication2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class DatosPersonales extends AppCompatActivity {

    TextView dpNombre, dpTelefono, dpEmail, dpDescripcion;
    EditText nombre, telefono, email, descripcion;
    Button dpButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datos_personales);

        dpNombre = (TextView) findViewById(R.id.dpNombre);
        dpTelefono = (TextView) findViewById(R.id.dpTelefono);
        dpEmail = (TextView) findViewById(R.id.dpEmail);
        dpDescripcion = (TextView) findViewById(R.id.dpDescripcion);
        dpButton = (Button) findViewById(R.id.dpButton);

        dpButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                onBackPressed();

                                        }
                                    });

            mostrarDatos();

        }

    private void mostrarDatos() {
            Bundle datos = this.getIntent().getExtras();
            String nombre = datos.getString("nom");
            String telefono = datos.getString("tel");
            String email = datos.getString("mail");
            String descripcion = datos.getString("desc");

            dpNombre.setText(nombre);
            dpTelefono.setText(telefono);
            dpEmail.setText(email);
            dpDescripcion.setText(descripcion);


        }}

